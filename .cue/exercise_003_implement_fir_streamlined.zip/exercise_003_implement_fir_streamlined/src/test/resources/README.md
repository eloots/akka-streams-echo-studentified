implement_a_fir_streamlined

## Construction of a simple FIR based echo generator using DelayLine

Building an FIR based echo generator from a simple *Echo generator Spec*

Demonstrates building a Flow using folding of filter stages over an initial
flow