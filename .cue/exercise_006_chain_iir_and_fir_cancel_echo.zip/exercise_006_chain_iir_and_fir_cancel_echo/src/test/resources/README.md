cancel_echo

## Implement echo cancellation

Using the appropriate combination of IIR/FIR filter, echos generated
by a first filter can be cancelled out by a subsequent filter

