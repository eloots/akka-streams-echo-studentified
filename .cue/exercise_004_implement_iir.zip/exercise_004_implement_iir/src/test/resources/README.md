implement_iir

## Implement an Infinite Impulse Response Filter

Implementation of an `IIR` filter using Akka Streams Flow Graph DSL

What is special about this is that feedback is modelled using this DSL.

It also demonstrates the problem of deadlock and a solution for it.
