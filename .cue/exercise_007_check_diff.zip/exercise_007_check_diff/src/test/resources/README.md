cancel_echo_verification

## Verify proper functioning of echo cancellation

Using the GraphDSL, we construct the flow that creates an audio stream that
is the difference between the original audio input stream and the processed
signal.

The result indeed is **silence**
