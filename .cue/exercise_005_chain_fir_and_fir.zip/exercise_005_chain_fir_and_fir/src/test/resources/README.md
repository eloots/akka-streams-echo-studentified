chain_fir_and_fir

## Simple chaining of two FIR filters

A naive attempt at echo cancellation.

Look at test result by actually enabling the test (in `FIRFIRSpec`)

